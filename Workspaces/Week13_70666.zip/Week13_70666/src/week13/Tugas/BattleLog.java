package week13.Tugas;

public interface BattleLog {
	public abstract void playerHitBack(Player player, int damageReductionFromBoss);
	
	public abstract void reportBattle(Player player, int damageTakenBoss, int hitPoint);
}
