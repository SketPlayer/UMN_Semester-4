module Week11_70666 {
	requires java.xml;
	requires java.xml.bind;
}