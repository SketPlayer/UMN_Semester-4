package week07.rio.ac.id.umn;

public interface EmployeeAddedListener {
	public void onEmployeeAdded(Employee employee);
}
