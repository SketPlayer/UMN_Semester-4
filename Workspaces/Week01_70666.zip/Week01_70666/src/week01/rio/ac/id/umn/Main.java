package week01.rio.ac.id.umn;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Selamat datang di aplikasi sederhana pertama !");
	}

}
