package week07.rio.ac.id.umn.Tugas;

public interface ClassInfo {
	public String getClassName();
}
