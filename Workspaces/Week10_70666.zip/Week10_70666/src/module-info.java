module Week10_70666 {
	requires java.xml;
	requires java.xml.bind;
}